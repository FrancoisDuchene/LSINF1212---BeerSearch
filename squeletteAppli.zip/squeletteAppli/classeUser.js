export class User
{
getAccountNumber(){// renvoie le nuéro de compte bancaire
  throw new Error("not yet implemented");
}
getBalance(){// renvoie le solde du compte
  throw new Error("not yet implemented");
}
getName(){// renvoie le nom de l'utilisateur
  throw new Error("not yet implemented");
}
getPlace(){// renvoie le poitn géographqie d'où la rêquète est faite
  throw new Error("not yet implemented");
}
sendMessage(string message){// envoie un message qqc à l'utilisateur
  throw new Error("not yet implemented");
}
supplyAccount(double quantity){ // ajoute une quantité d'argent au compte
  throw new Error("not yet implemented");
}
removeAccount(double quantity){// enlève une quantité d'argent au copmpte
  throw new Error("not yet implemented");
}
}
