export class Beer
{
  getNom() {// renvoie le nom de la bière
    throw new Error("not yet implemented");
  }
  getDegree(){//renvoie le taux d'alcohol de la bière
    throw new Error("not yet implemented");
  }
  getSellPlace(){// renvoie les points de vente qui disposent de la bière
    throw new Error("not yet implemented");
  }
  getType(){ // renvoie le type de la bière
    throw new Error("not yet implemented");
  }
  getTaste(){// renvoie le goût de la bière
    throw new Error("not yet implemented");
  }
}
